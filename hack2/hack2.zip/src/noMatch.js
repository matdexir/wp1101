import React from 'react'

function NoMatch() {
  return (
    <div style={{ position: 'absolute', top: '200px', left: '200px' }}>
      404 Not Found
    </div>
  )
}

export default NoMatch
