export const TODO = "TODO";
export const INPROGRESS = "INPROGRESS";
export const DONE = "DONE";
