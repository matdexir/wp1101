/****************************************************************************
  FileName      [ index.js ]
  PackageName   [  ]
  Author        [ Cheng-Hua Lu, Chin-Yi Cheng ]
  Synopsis      [  ]
  Copyright     [ 2021 10 ]
****************************************************************************/

import React from 'react';
import ReactDOM from 'react-dom';

import App from './App';

ReactDOM.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
  
  document.getElementById('root')
);


